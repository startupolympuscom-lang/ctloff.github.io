"use client"

import { HeroSection } from "@/components/hero-section"
import { IntroFeaturesSection } from "@/components/intro-features-section"
import { HomeProductsSection } from "@/components/home-products-section"
import { TestimonialsSection } from "@/components/testimonials-section"
import { ContactSection } from "@/components/contact-section"
import { FounderSection } from "@/components/founder-section"

export default function HomePage() {
  return (
    <div id="top" className="min-h-screen">
      <HeroSection />
      <IntroFeaturesSection />
      <HomeProductsSection />
      <FounderSection />
      <TestimonialsSection />
      <ContactSection />
    </div>
  )
}
