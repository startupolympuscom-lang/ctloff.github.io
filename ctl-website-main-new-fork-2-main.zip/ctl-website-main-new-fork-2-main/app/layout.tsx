import type React from "react"
import type { Metadata } from "next"
import { Inter, Plus_Jakarta_Sans } from "next/font/google"
import "./globals.css"
import { LanguageProvider } from "@/lib/language-context"
import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
  display: "swap",
})

const plusJakartaSans = Plus_Jakarta_Sans({
  subsets: ["latin"],
  variable: "--font-plus-jakarta-sans",
  display: "swap",
})

export const metadata: Metadata = {
  title: "CTL - Your Digital Transformation Partner",
  description:
    "CTL builds AI-driven solutions that save time, boost sales, and keep you ahead. Work less. Achieve more.",
  keywords: "AI, Digital Transformation, Morocco, Technology, Automation, Business Solutions",
  authors: [{ name: "CTL - Charikate Tikniate Lrhade" }],
  creator: "CTL",
  publisher: "CTL",
  robots: "index, follow",
  openGraph: {
    type: "website",
    locale: "en_US",
    url: "https://ctl-morocco.com",
    title: "CTL - Your Digital Transformation Partner",
    description: "CTL builds AI-driven solutions that save time, boost sales, and keep you ahead.",
    siteName: "CTL",
  },
  twitter: {
    card: "summary_large_image",
    title: "CTL - Your Digital Transformation Partner",
    description: "CTL builds AI-driven solutions that save time, boost sales, and keep you ahead.",
  },
  generator: "v0.dev",
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" className={`${inter.variable} ${plusJakartaSans.variable}`}>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
      </head>
      <body className={`${inter.className} antialiased`}>
        <LanguageProvider>
          <div className="min-h-screen flex flex-col">
            <Navigation />
            <main id="top" className="flex-1">
              {children}
            </main>
            <Footer />
          </div>
        </LanguageProvider>
      </body>
    </html>
  )
}
