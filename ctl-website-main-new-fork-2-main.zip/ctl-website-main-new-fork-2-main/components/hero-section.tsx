"use client"

import { Button } from "@/components/ui/button"
import Link from "next/link"
import { ArrowRight, Phone } from "lucide-react"
import { useLanguage } from "@/lib/language-context"

export function HeroSection() {
  const { t } = useLanguage()

  return (
    <section
      id="hero"
      className="relative bg-moroccan-yellow text-moroccan-charcoal min-h-screen flex items-center overflow-hidden"
    >
      <div className="absolute inset-0 bg-[url('/placeholder.svg?height=800&width=1200')] opacity-5"></div>
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        <div className="flex flex-col items-center gap-12">
          <div className="flex-1 text-center space-y-8">
            <h1 className="text-5xl md:text-7xl lg:text-8xl font-display font-bold leading-tight tracking-tight">
              {t.home.heroTitle.split(" ").slice(0, -1).join(" ")}{" "}
              <span className="gradient-text">{t.home.heroTitle.split(" ").slice(-1)[0]}</span>
            </h1>
            <h2 className="text-4xl font-display font-bold text-moroccan-charcoal mb-4">{t.home.heroSlogan}</h2>
            <p className="text-lg md:text-xl text-gray-700 mx-auto leading-relaxed max-w-4xl">
              {t.home.heroDescription}
            </p>

            <div className="flex flex-col sm:flex-row gap-6 justify-center items-center pt-8">
              <Button
                asChild
                variant="ghost"
                size="xl"
                className="group relative overflow-hidden backdrop-blur-sm bg-white/10 border border-white/20 text-moroccan-charcoal hover:bg-black hover:border-black hover:text-moroccan-yellow px-12 py-6 rounded-full shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105 hover:-translate-y-1"
              >
                <Link href="/contact" className="flex items-center space-x-3 relative z-10">
                  <div className="p-2 rounded-full bg-white/20 group-hover:bg-moroccan-yellow/20 transition-all duration-300">
                    <Phone className="h-5 w-5 group-hover:text-moroccan-yellow transition-colors duration-300" />
                  </div>
                  <span className="font-bold text-lg">{t.common.getDemo}</span>
                  <ArrowRight className="h-5 w-5 group-hover:translate-x-1 group-hover:text-moroccan-yellow transition-all duration-300" />
                  <div className="absolute inset-0 rounded-full bg-gradient-to-r from-white/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                </Link>
              </Button>
              <Button
                asChild
                variant="ghost"
                size="xl"
                className="group relative overflow-hidden bg-moroccan-charcoal border border-moroccan-charcoal text-moroccan-yellow hover:bg-moroccan-charcoal/90 hover:border-moroccan-charcoal/90 hover:text-moroccan-yellow px-12 py-6 rounded-full shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105 hover:-translate-y-1"
              >
                <Link href="/about" className="flex items-center space-x-3 relative z-10">
                  <span className="font-bold text-lg">{t.common.learnMore}</span>
                  <div className="absolute inset-0 rounded-full bg-gradient-to-r from-moroccan-yellow/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
